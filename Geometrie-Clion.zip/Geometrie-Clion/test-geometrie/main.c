// -------------------------------------------
/*
main.c
Auteur:

Date: Automne 2021
Description: programme de test des fonctions de la Librairie geometrie
Note: les r�sultats de test peuvent �tre compar�s avec ceux des calculateurs suivants
    - solution_systeme_2eq      http://calculis.net/systeme-equation
    - equation_droite           http://calculis.net/droite
    - intersection droite       http://calculis.net/intersection

*/
// -------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include "geometrie.h"

int main()
{
    double x,y;   // pour la solution d'un syst�me d'�quation

    // tests de la fonction solution_systeme_2eq
    // comparer les r�sultats avec http://calculis.net/systeme-equation
    if (solution_systeme_2eq(7,12,8,5,-4,-1,&x,&y))
        printf("\nLa solution du systeme est: %f,%f\n",x,y);
    else
        printf("\npas de solution unique au systeme d'equations\n");

    ///*** � compl�ter                                      ***///
    ///*** ins�rer vos autres tests ici pour les fonctions  ***///
    ///***        equation_droite                           ***///
    ///***        intersection_droites                      ***///
    ///***        intersection_segments                     ***///


    return EXIT_SUCCESS;
}
